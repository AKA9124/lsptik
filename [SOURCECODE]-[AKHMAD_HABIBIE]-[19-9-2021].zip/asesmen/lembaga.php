<!doctype html> 
<html> 
<head> 
	<meta charset="utf-8"> 
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="assets/css/bootstrap.css"> 
	<title>Lembaga - Asesment Akhmad Habibie</title> 
</head> 
<body>

<?php
include "navbar.php";
?>


	<div class="container">
		<br>
		<div class="bd-example">
			<div class="col-s12">
				<h1 style="text-align: center;">Lembaga Sertifikasi Profesi</h1>
				<br>
				<img src="gambar/profil1.jpeg" style="text-align: center;">
			</div>
		</div>

	</div>

	<script src="assets/js/jquery.js"></script> 
	<script src="assets/js/popper.js"></script> 
	<script src="assets/js/bootstrap.js"></script><script src="https://use.fontawesome.com/3ee4e4a3e0.js"></script>
</body> 
</html>